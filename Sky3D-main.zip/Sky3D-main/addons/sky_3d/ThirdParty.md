## Attribution for Third Party Assets

`Milkyway.jpg` "[The Milky Way panorama](https://www.eso.org/public/images/eso0932a/)" by ESO/S. Brunier, licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/
).
[Read more](/addons/sky_3d/assets/thirdparty/textures/milkyway/LICENSE.md)

`MoonMap.png` Copyright (c) 2019 GPoSM, MIT License
[Read more](/addons/sky_3d/assets/thirdparty/textures/moon/LICENSE.md)
